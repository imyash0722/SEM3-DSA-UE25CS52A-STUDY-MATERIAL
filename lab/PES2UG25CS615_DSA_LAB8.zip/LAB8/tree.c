#include <stdio.h>
#include <stdlib.h>
#include "tree.h" 

void init(tree_t *ptr_tree)
{
	ptr_tree->root_ = -1;
	ptr_tree->count_ = 0;
	init_stack(&ptr_tree->stack_);
	for(int i = MAXSIZE - 1; i >= 0; --i)
	{
		push(&ptr_tree->stack_, i);
	}
}

int insert_recursive(node_t elem[], int root, int temp)
{
	if(root == -1)
	{
		root = temp;
	}
	else if(elem[root].key_ > elem[temp].key_)
	{
		elem[root].left_ = insert_recursive(elem, elem[root].left_, temp);
	}
	else
	{
		elem[root].right_ = insert_recursive(elem, elem[root].right_, temp);
	}
	return root;
}
void insert(tree_t *ptr_tree, int key)
{
	
	int temp = pop(&ptr_tree->stack_);
	if(temp == -1)
	{
		printf("tree full; cannot insert %d\n", key);
		return;
	}
	ptr_tree->count_++;
	
	ptr_tree->elem_[temp].key_ = key;
	ptr_tree->elem_[temp].left_ = ptr_tree->elem_[temp].right_ = -1;
	ptr_tree->root_ = insert_recursive(ptr_tree->elem_, ptr_tree->root_, temp);
}

void disp_recursive(node_t elem[], int temp)
{
		if(temp != -1)
		{
			disp_recursive(elem, elem[temp].left_);
			printf("%d ", elem[temp].key_);
			disp_recursive(elem, elem[temp].right_);
		}
		
}


void disp(tree_t *ptr_tree)
{
	disp_recursive(ptr_tree->elem_, ptr_tree->root_); 
	printf("\n\n");
}

int inorder_successor(node_t elem[], int root)
{
	int temp = elem[root].right_;
	while(elem[temp].left_ != -1)
	{
		temp = elem[temp].left_;
	}
	return temp;
}

int delete_key_recursive(tree_t *ptr_tree, int root, int key, int *found)
{
	if(root == -1)
	{
		return -1;
	}
	
	else if(key < ptr_tree->elem_[root].key_)
	{
		ptr_tree->elem_[root].left_ = delete_key_recursive(ptr_tree, ptr_tree->elem_[root].left_, key, found);
	}

	else if(key > ptr_tree->elem_[root].key_)
	{
		ptr_tree->elem_[root].right_ = delete_key_recursive(ptr_tree, ptr_tree->elem_[root].right_, key, found);
	}
	
	else 
	{
		*found = 1;
		if(ptr_tree->elem_[root].left_ == -1 && ptr_tree->elem_[root].right_ == -1)
		{
			push(&ptr_tree->stack_, root);
			ptr_tree->count_--;
			return -1;
		}
		else if(ptr_tree->elem_[root].left_ == -1)
		{
			int temp = ptr_tree->elem_[root].right_;
			push(&ptr_tree->stack_, root);
			ptr_tree->count_--;
			return temp;
		}
		else if(ptr_tree->elem_[root].right_ == -1)
		{
			int temp = ptr_tree->elem_[root].left_;
			push(&ptr_tree->stack_, root);
			ptr_tree->count_--;
			return temp;
		}
		else 
		{
			int temp = inorder_successor(ptr_tree->elem_, root);
			ptr_tree->elem_[root].key_ = ptr_tree->elem_[temp].key_;
			ptr_tree->elem_[root].right_ = delete_key_recursive(ptr_tree, ptr_tree->elem_[root].right_, ptr_tree->elem_[temp].key_, found);
			return root;
		}
	}
	return root;
}

int delete_key(tree_t *ptr_tree, int key)
{
	int found = 0;
	ptr_tree->root_ = delete_key_recursive(ptr_tree, ptr_tree->root_, key, &found);
	if(! found)
	{
		printf("key not found\n");
	}
	return found;
}
