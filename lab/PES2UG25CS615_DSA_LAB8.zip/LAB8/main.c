#include <stdio.h>
#include <stdlib.h>
#include "tree.h"

int main()
{
	tree_t tree;
	init(&tree);

	int choice;
	int key;

	while(1)
	{
		printf("\n=== Binary Search Tree Menu ===\n");
		printf("1. Insert a key\n");
		printf("2. Delete a key\n");
		printf("3. Display tree (inorder)\n");
		printf("4. Exit\n");
		printf("Enter your choice: ");

		if(scanf("%d", &choice) != 1)
		{
			break;
		}

		switch(choice)
		{
			case 1:
				printf("Enter key to insert: ");
				if(scanf("%d", &key) == 1)
				{
					insert(&tree, key);
				}
				break;

			case 2:
				printf("Enter key to delete: ");
				if(scanf("%d", &key) == 1)
				{
					delete_key(&tree, key);
				}
				break;

			case 3:
				printf("Display (inorder): ");
				disp(&tree);
				break;

			case 4:
				printf("Exiting...\n");
				exit(0);

			default:
				printf("Invalid choice. Please try again.\n");
				break;
		}
	}

	return 0;
}
