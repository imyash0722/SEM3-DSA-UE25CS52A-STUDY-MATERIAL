#include <stdio.h>
#include <stdlib.h>
#include "graph.h"

#define DEBUG 0

/**
 * Purpose: Initialize graph structure with vertex and edge counts, zeroing the adjacency matrix.
 * Parameters: ptr_graph - pointer to graph_t struct, n_vertices - vertex count, n_edges - edge count.
 * Return: None.
 */
void init_graph(graph_t *ptr_graph, int n_vertices, int n_edges)
{
	ptr_graph->n_vertices_ = n_vertices;
	ptr_graph->n_edges_ = n_edges;
	for (int i = 0; i < ptr_graph->n_vertices_; ++i)
	{
		for (int j = 0; j < ptr_graph->n_vertices_; ++j)
		{
			ptr_graph->adj_mat_[i][j] = 0;
		}
	}
}

/**
 * Purpose: Add an undirected edge between vertices 'from' and 'to'.
 * Parameters: ptr_graph - pointer to graph_t struct, from - first vertex, to - second vertex.
 * Return: None.
 */
void add_edge(graph_t *ptr_graph, int from, int to)
{
	if (DEBUG)
	{
		printf("Adding an edge %d - %d\n", from, to);
	}
	ptr_graph->adj_mat_[from][to] = 1;
	ptr_graph->adj_mat_[to][from] = 1;
}

/**
 * Purpose: Recursive DFS traversal printing visited vertices.
 * Parameters: ptr_graph - pointer to graph_t struct, visited - array of visited flags, u - current vertex.
 * Return: None.
 */
static void dfs_recursive(graph_t *ptr_graph, int visited[], int u)
{
	visited[u] = 1;
	printf("visited %d \n", u);
	for (int i = 0; i < ptr_graph->n_vertices_; ++i)
	{
		if (ptr_graph->adj_mat_[u][i] && !visited[i])
		{
			dfs_recursive(ptr_graph, visited, i);
		}
	}
}

/**
 * Purpose: Perform depth-first search starting from vertex u.
 * Parameters: ptr_graph - pointer to graph_t struct, u - starting vertex.
 * Return: None.
 */
void dfs(graph_t *ptr_graph, int u)
{
	int visited[MAXSIZE];
	for (int i = 0; i < ptr_graph->n_vertices_; ++i)
	{
		visited[i] = 0;
	}
	dfs_recursive(ptr_graph, visited, u);
	printf("\n");
}

/**
 * Purpose: Display the adjacency matrix with vertex labels (A, B, C, ...).
 * Parameters: ptr_graph - pointer to graph_t struct.
 * Return: None.
 */
void disp(graph_t *ptr_graph)
{
	printf("    ");
	for (int i = 0; i < ptr_graph->n_vertices_; ++i)
	{
		printf("%c%s", 'A' + i, (i == ptr_graph->n_vertices_ - 1) ? "" : "  ");
	}
	printf("\n");
	for (int i = 0; i < ptr_graph->n_vertices_; ++i)
	{
		printf("%c   ", 'A' + i);
		for (int j = 0; j < ptr_graph->n_vertices_; ++j)
		{
			printf("%d%s", ptr_graph->adj_mat_[i][j], (j == ptr_graph->n_vertices_ - 1) ? "" : "  ");
		}
		printf("\n");
	}
}

/**
 * Purpose: Deinitialize graph structure by resetting vertex and edge counts.
 * Parameters: ptr_graph - pointer to graph_t struct.
 * Return: None.
 */
void deinit_graph(graph_t *ptr_graph)
{
	ptr_graph->n_vertices_ = 0;
	ptr_graph->n_edges_ = 0;
}

/**
 * Purpose: Calculate the degree of vertex v (row sum).
 * Parameters: g - pointer to graph_t struct, v - vertex index.
 * Return: Degree of vertex v.
 */
int degree(graph_t *g, int v)
{
	if (g == NULL || v < 0 || v >= g->n_vertices_)
	{
		return 0;
	}
	int deg = 0;
	for (int i = 0; i < g->n_vertices_; ++i)
	{
		deg += g->adj_mat_[v][i];
	}
	return deg;
}

/**
 * Purpose: Count total edges from upper triangle of the adjacency matrix.
 * Parameters: g - pointer to graph_t struct.
 * Return: Number of edges.
 */
int count_edges(graph_t *g)
{
	if (g == NULL)
	{
		return 0;
	}
	int count = 0;
	for (int i = 0; i < g->n_vertices_; ++i)
	{
		for (int j = i + 1; j < g->n_vertices_; ++j)
		{
			if (g->adj_mat_[i][j])
			{
				count++;
			}
		}
	}
	return count;
}

/**
 * Purpose: Recursive DFS traversal without printing (for connectivity and reachability checks).
 * Parameters: ptr_graph - pointer to graph_t struct, visited - array of visited flags, u - current vertex.
 * Return: None.
 */
static void dfs_silent(graph_t *ptr_graph, int visited[], int u)
{
	visited[u] = 1;
	for (int i = 0; i < ptr_graph->n_vertices_; ++i)
	{
		if (ptr_graph->adj_mat_[u][i] && !visited[i])
		{
			dfs_silent(ptr_graph, visited, i);
		}
	}
}

/**
 * Purpose: Check if all vertices are reachable from vertex 0 using non-printing DFS.
 * Parameters: g - pointer to graph_t struct.
 * Return: 1 if all vertices are reachable from vertex 0, 0 otherwise.
 */
int is_connected(graph_t *g)
{
	if (g == NULL || g->n_vertices_ <= 0)
	{
		return 0;
	}
	int visited[MAXSIZE];
	for (int i = 0; i < g->n_vertices_; ++i)
	{
		visited[i] = 0;
	}
	dfs_silent(g, visited, 0);
	for (int i = 0; i < g->n_vertices_; ++i)
	{
		if (!visited[i])
		{
			return 0;
		}
	}
	return 1;
}

/**
 * Purpose: Check if graph has Euler circuit (2), Euler path only (1), or neither (0).
 * Parameters: g - pointer to graph_t struct.
 * Return: 2 for Euler circuit, 1 for Euler path only, 0 for not Eulerian.
 */
int check_eulerian(graph_t *g)
{
	if (g == NULL || g->n_vertices_ <= 0 || count_edges(g) == 0)
	{
		return 0;
	}

	/* Find first vertex with non-zero degree */
	int start_v = -1;
	for (int i = 0; i < g->n_vertices_; ++i)
	{
		if (degree(g, i) > 0)
		{
			start_v = i;
			break;
		}
	}
	if (start_v == -1)
	{
		return 0;
	}

	/* Check if all vertices with degree > 0 are in the same component */
	int visited[MAXSIZE];
	for (int i = 0; i < g->n_vertices_; ++i)
	{
		visited[i] = 0;
	}
	dfs_silent(g, visited, start_v);
	for (int i = 0; i < g->n_vertices_; ++i)
	{
		if (degree(g, i) > 0 && !visited[i])
		{
			return 0; /* Edges lie in more than one connected component */
		}
	}

	/* Count vertices with odd degree */
	int odd_count = 0;
	for (int i = 0; i < g->n_vertices_; ++i)
	{
		if (degree(g, i) % 2 != 0)
		{
			odd_count++;
		}
	}

	if (odd_count == 0)
	{
		return 2; /* Euler circuit exists */
	}
	if (odd_count == 2)
	{
		return 1; /* Euler path only exists */
	}
	return 0;     /* Not Eulerian */
}

/**
 * Purpose: Check if the graph forms a star topology (n >= 3).
 * Parameters: g - pointer to graph_t struct.
 * Return: Hub vertex index if star topology, -1 otherwise.
 */
int check_star(graph_t *g)
{
	if (g == NULL || g->n_vertices_ < 3)
	{
		return -1;
	}
	int n = g->n_vertices_;
	int hub = -1;
	int hub_count = 0;
	int leaf_count = 0;

	for (int i = 0; i < n; ++i)
	{
		int d = degree(g, i);
		if (d == n - 1)
		{
			hub = i;
			hub_count++;
		}
		else if (d == 1)
		{
			leaf_count++;
		}
	}

	if (hub_count == 1 && leaf_count == n - 1)
	{
		return hub;
	}
	return -1;
}

/**
 * Purpose: Identify network topology of the graph.
 * Parameters: g - pointer to graph_t struct.
 * Return: Value of enum topology representing the classification.
 */
topology_t identify_topology(graph_t *g)
{
	if (g == NULL || g->n_vertices_ < 2 || !is_connected(g))
	{
		return NOT_NETWORK;
	}

	int n = g->n_vertices_;
	int edges = count_edges(g);

	/* 1. RING: Single cycle, n >= 3. Quick check: All degrees are 2 */
	if (n >= 3)
	{
		int all_deg_2 = 1;
		for (int i = 0; i < n; ++i)
		{
			if (degree(g, i) != 2)
			{
				all_deg_2 = 0;
				break;
			}
		}
		if (all_deg_2)
		{
			return RING;
		}
	}

	/* 2. BUS: Single path. Quick check: Edges = n-1, two vertices of degree 1, rest degree 2 */
	if (edges == n - 1)
	{
		int deg_1 = 0;
		int deg_2 = 0;
		for (int i = 0; i < n; ++i)
		{
			int d = degree(g, i);
			if (d == 1)
			{
				deg_1++;
			}
			else if (d == 2)
			{
				deg_2++;
			}
		}
		if (deg_1 == 2 && deg_2 == n - 2)
		{
			return BUS;
		}
	}

	/* 3. STAR: One hub, others are leaves. Quick check: check_star() != -1 */
	if (check_star(g) != -1)
	{
		return STAR;
	}

	/* 4. FULL_MESH: Every pair connected. Quick check: All degrees are n-1 */
	int all_deg_n_minus_1 = 1;
	for (int i = 0; i < n; ++i)
	{
		if (degree(g, i) != n - 1)
		{
			all_deg_n_minus_1 = 0;
			break;
		}
	}
	if (all_deg_n_minus_1)
	{
		return FULL_MESH;
	}

	/* 5. TREE: Connected, acyclic, not bus or star. Quick check: Edges = n-1 */
	if (edges == n - 1)
	{
		return TREE;
	}

	/* 6. HYBRID: Connected, none of the above. Quick check: Fallback */
	return HYBRID;
}

/**
 * Purpose: Return printable string name of a topology enum value.
 * Parameters: t - topology enum value.
 * Return: Constant string describing topology name.
 */
const char *topology_name(topology_t t)
{
	switch (t)
	{
		case RING:
			return "Ring";
		case BUS:
			return "Bus";
		case STAR:
			return "Star";
		case FULL_MESH:
			return "Full Mesh";
		case TREE:
			return "Tree";
		case HYBRID:
			return "Hybrid";
		case NOT_NETWORK:
			return "Not a network";
		default:
			return "Unknown";
	}
}
