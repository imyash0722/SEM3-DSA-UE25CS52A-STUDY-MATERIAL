#include <stdio.h>
#include "graph.h"

/**
 * Purpose: Build a graph from an edge list, display it, and print property checks.
 * Parameters: title - test case name, n_vertices - vertex count, n_edges - edge count,
 *             edges - array of vertex pairs.
 * Return: None.
 */
static void test_graph(const char *title, int n_vertices, int n_edges, int edges[][2])
{
	graph_t g;
	init_graph(&g, n_vertices, n_edges);

	for (int i = 0; i < n_edges; ++i)
	{
		add_edge(&g, edges[i][0], edges[i][1]);
	}

	printf("==== %s ====\n", title);
	disp(&g);

	int euler = check_eulerian(&g);
	if (euler == 2)
	{
		printf("Eulerian check   : Euler circuit exists\n");
	}
	else if (euler == 1)
	{
		printf("Eulerian check   : Euler path only exists\n");
	}
	else
	{
		printf("Eulerian check   : Not Eulerian\n");
	}

	int hub = check_star(&g);
	if (hub != -1)
	{
		printf("Star check       : Star, hub = %c\n", 'A' + hub);
	}
	else
	{
		printf("Star check       : Not a star\n");
	}

	topology_t topo = identify_topology(&g);
	printf("Network topology : %s\n\n", topology_name(topo));

	deinit_graph(&g);
}

int main(void)
{
	/* Test Case 1: Handout graph (8 vertices, 11 edges) */
	int e1[][2] = {
		{0, 1}, {0, 2}, {1, 2}, {1, 3}, {2, 4},
		{3, 4}, {3, 5}, {4, 6}, {5, 6}, {5, 7}, {6, 7}
	};
	test_graph("Handout graph (8 vertices, 11 edges)", 8, 11, e1);

	/* Test Case 2: Cycle of 5 vertices */
	int e2[][2] = {
		{0, 1}, {1, 2}, {2, 3}, {3, 4}, {4, 0}
	};
	test_graph("Cycle of 5", 5, 5, e2);

	/* Test Case 3: Path of 4 vertices */
	int e3[][2] = {
		{0, 1}, {1, 2}, {2, 3}
	};
	test_graph("Path of 4 vertices", 4, 3, e3);

	/* Test Case 4: Star with 1 hub and 5 leaves */
	int e4[][2] = {
		{0, 1}, {0, 2}, {0, 3}, {0, 4}, {0, 5}
	};
	test_graph("Star with 1 hub and 5 leaves", 6, 5, e4);

	/* Test Case 5: Complete graph K5 */
	int e5[][2] = {
		{0, 1}, {0, 2}, {0, 3}, {0, 4},
		{1, 2}, {1, 3}, {1, 4},
		{2, 3}, {2, 4},
		{3, 4}
	};
	test_graph("Complete graph K5", 5, 10, e5);

	/* Test Case 6: Binary tree, 7 vertices */
	int e6[][2] = {
		{0, 1}, {0, 2},
		{1, 3}, {1, 4},
		{2, 5}, {2, 6}
	};
	test_graph("Binary tree, 7 vertices", 7, 6, e6);

	/* Test Case 7: Bow-tie (two triangles sharing a vertex) */
	int e7[][2] = {
		{0, 1}, {1, 2}, {2, 0},
		{0, 3}, {3, 4}, {4, 0}
	};
	test_graph("Bow-tie (two triangles sharing a vertex)", 5, 6, e7);

	/* Test Case 8: Disconnected graph */
	int e8[][2] = {
		{0, 1}, {1, 2}, {2, 0},
		{3, 4}
	};
	test_graph("Disconnected graph", 5, 4, e8);

	return 0;
}
