#include "poly.h"
#include <stdio.h>
#include <stdlib.h>

int main(void) {
    int choice;

    printf("=== Polynomial ADT Laboratory ===\n");
    printf("1. Part A - Polynomial Addition\n");
    printf("2. Part B - Definite Integration\n");
    printf("Select part (1 or 2): ");
    scanf("%d", &choice);

    if (choice == 1) {
        poly_t poly1, poly2, sum;

        printf("\nEnter first polynomial:\n");
        poly1 = create_poly();

        printf("\nEnter second polynomial:\n");
        poly2 = create_poly();

        add_poly(poly1, poly2, &sum);

        printf("\nPolynomial 1: ");
        display_poly(poly1);
        printf("Polynomial 2: ");
        display_poly(poly2);
        printf("Sum         : ");
        display_poly(sum);

        destroy_poly(&poly1);
        destroy_poly(&poly2);
        destroy_poly(&sum);

    } else if (choice == 2) {
        poly_t poly, integrated_poly;
        double lower_limit, upper_limit;
        double result;

        printf("\nEnter the polynomial to integrate:\n");
        poly = create_poly();

        integrated_poly = integrate_poly(poly);

        printf("\nEnter lower limit: ");
        scanf("%lf", &lower_limit);
        printf("Enter upper limit: ");
        scanf("%lf", &upper_limit);

        result = eval_poly(integrated_poly, upper_limit)
               - eval_poly(integrated_poly, lower_limit);

        printf("\nPolynomial           : ");
        display_poly(poly);
        printf("Integrated Polynomial: ");
        display_poly(integrated_poly);
        printf("Definite integral from %.2lf to %.2lf = %.4lf\n",
               lower_limit, upper_limit, result);

        destroy_poly(&poly);
        destroy_poly(&integrated_poly);

    } else {
        printf("Invalid choice!\n");
        return 1;
    }

    return 0;
}
