#include "poly.h"
#include "term.h"
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

poly_t create_poly(void) {
    int n;
    printf("Number of terms: ");
    scanf("%d", &n);

    poly_t head = NULL;
    poly_t *tail = &head;

    for (int i = 0; i < n; i++) {
        double coeff;
        int exp;
        printf("Coefficient Exponent: ");
        scanf("%lf %d", &coeff, &exp);

        term_t *new_node = create_term(coeff, exp);
        *tail = new_node;
        tail = &(new_node->next);
    }

    return head;
}

void display_poly(poly_t poly) {
    if (poly == NULL) {
        printf("0\n");
        return;
    }

    int is_first = 1;
    for (term_t *current = poly; current != NULL; current = current->next) {
        print_term(current, is_first);
        is_first = 0;
    }
    printf("\n");
}

void add_poly(poly_t poly1, poly_t poly2, poly_t *sum) {
    *sum = NULL;
    poly_t *tail = sum;

    term_t *ptr1 = poly1;
    term_t *ptr2 = poly2;

    while (ptr1 != NULL && ptr2 != NULL) {
        if (ptr1->exp > ptr2->exp) {
            term_t *new_node = create_term(ptr1->coeff, ptr1->exp);
            *tail = new_node;
            tail = &(new_node->next);
            ptr1 = ptr1->next;
        } else if (ptr1->exp < ptr2->exp) {
            term_t *new_node = create_term(ptr2->coeff, ptr2->exp);
            *tail = new_node;
            tail = &(new_node->next);
            ptr2 = ptr2->next;
        } else {
            double sum_coeff = ptr1->coeff + ptr2->coeff;
            if (sum_coeff != 0.0) {
                term_t *new_node = create_term(sum_coeff, ptr1->exp);
                *tail = new_node;
                tail = &(new_node->next);
            }
            ptr1 = ptr1->next;
            ptr2 = ptr2->next;
        }
    }

    while (ptr1 != NULL) {
        term_t *new_node = create_term(ptr1->coeff, ptr1->exp);
        *tail = new_node;
        tail = &(new_node->next);
        ptr1 = ptr1->next;
    }

    while (ptr2 != NULL) {
        term_t *new_node = create_term(ptr2->coeff, ptr2->exp);
        *tail = new_node;
        tail = &(new_node->next);
        ptr2 = ptr2->next;
    }
}

void destroy_poly(poly_t *poly) {
    term_t *current = *poly;
    while (current != NULL) {
        term_t *temp = current;
        current = current->next;
        free(temp);
    }
    *poly = NULL;
}

double eval_poly(poly_t poly, double x) {
    double result = 0.0;
    for (term_t *current = poly; current != NULL; current = current->next) {
        result += current->coeff * pow(x, current->exp);
    }
    return result;
}

poly_t integrate_poly(poly_t poly) {
    poly_t integrated = NULL;
    poly_t *tail = &integrated;

    for (term_t *current = poly; current != NULL; current = current->next) {
        term_t *new_node = (term_t*)malloc(sizeof(term_t));
        integrate_term(current, new_node);
        if (new_node->coeff != 0.0 || new_node->exp != 0) {
            new_node->next = NULL;
            *tail = new_node;
            tail = &(new_node->next);
        } else {
            free(new_node);
        }
    }

    return integrated;
}
