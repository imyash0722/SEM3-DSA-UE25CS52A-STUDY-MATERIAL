#include "term.h"
#include <stdlib.h>
#include <stdio.h>

term_t* create_term(double coeff, int exp) {
    term_t *new_term = (term_t*)malloc(sizeof(term_t));
    new_term->coeff = coeff;
    new_term->exp = exp;
    new_term->next = NULL;
    return new_term;
}

void print_term(term_t *ptr_term, int is_first) {
    if (ptr_term == NULL)
        return;

    if (!is_first) {
        if (ptr_term->coeff > 0)
            printf(" + ");
        else
            printf(" ");
    }

    if (ptr_term->exp == 0) {
        printf("%.0lf", ptr_term->coeff);
    } else if (ptr_term->exp == 1) {
        if (ptr_term->coeff == 1.0) {
            printf("x");
        } else if (ptr_term->coeff == -1.0) {
            printf("-x");
        } else {
            printf("%.0lfx", ptr_term->coeff);
        }
    } else {
        if (ptr_term->coeff == 1.0) {
            printf("x^%d", ptr_term->exp);
        } else if (ptr_term->coeff == -1.0) {
            printf("-x^%d", ptr_term->exp);
        } else {
            printf("%.0lfx^%d", ptr_term->coeff, ptr_term->exp);
        }
    }
}

void integrate_term(term_t *ptr_term, term_t *ptr_integrated_term) {
    if (ptr_term->exp == -1) {
        ptr_integrated_term->coeff = 0.0;
        ptr_integrated_term->exp = 0;
        return;
    }

    ptr_integrated_term->coeff = ptr_term->coeff / (ptr_term->exp + 1);
    ptr_integrated_term->exp = ptr_term->exp + 1;
}
