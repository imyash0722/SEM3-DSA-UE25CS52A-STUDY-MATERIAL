#include <stdio.h>
#include <stdlib.h>
#include "deque.h"

void init_dll(dll_t *ptr_dll)
{
	ptr_dll->front = ptr_dll->rear = NULL;
}

void deinit_dll(dll_t *ptr_dll)
{
	node_t* pres = ptr_dll->front;
	while(pres != NULL)
	{
		node_t* temp = pres;
		pres = pres->next;
		free(temp);
	}
	ptr_dll->front = ptr_dll->rear = NULL;
}

static node_t* create_node(int key)
{
    node_t *temp = (node_t*)malloc(sizeof(node_t));
    if (temp == NULL) {
        printf("Memory allocation failed\n");
        exit(1);
    }
    temp->key = key;
    temp->prev = NULL;
    temp->next = NULL;
    return temp;
}

void insertFront(dll_t *ptr_dll, int key)
{
	node_t *temp = create_node(key);
	if(ptr_dll->front == NULL)
	{
		ptr_dll->front = temp;
		ptr_dll->rear = temp;
	}
	else
	{
		temp->next = ptr_dll->front;
		ptr_dll->front->prev = temp;
		ptr_dll->front = temp;
	}
}

void insertRear(dll_t* ptr_dll, int key)
{
	node_t *temp = create_node(key);
	if(ptr_dll->front == NULL)
	{
		ptr_dll->front = temp;
		ptr_dll->rear = temp;
	}
	else
	{
		ptr_dll->rear->next = temp;
		temp->prev = ptr_dll->rear;
		ptr_dll->rear = temp;
	}
}

void display(dll_t *ptr_dll)
{
	node_t *temp = ptr_dll->front;
	printf("Front -> ");
	while(temp != NULL)
	{
		printf("%d ", temp->key);
		temp = temp->next;
	}
	printf("<- Rear\n");
}

int deleteFront(dll_t *ptr_dll)
{
	if(ptr_dll->front == NULL)
	{
		printf("list is empty\n");
		return 0;
	}
	node_t *temp = ptr_dll->front;
	int key = ptr_dll->front->key;
	if(ptr_dll->front == ptr_dll->rear)
	{
		ptr_dll->front = ptr_dll->rear = NULL;
	}
	else
	{
		ptr_dll->front = temp->next;
		ptr_dll->front->prev = NULL;
	}
	free(temp);
	return key;
}

int deleteRear(dll_t *ptr_dll)
{
	if(ptr_dll->rear == NULL)
	{
		printf("list is empty\n");
		return 0;
	}
	node_t *temp = ptr_dll->rear;
	int key = ptr_dll->rear->key;
	if(ptr_dll->front == ptr_dll->rear)
	{
		ptr_dll->front = ptr_dll->rear = NULL;
	}
	else
	{
		ptr_dll->rear = temp->prev;
		ptr_dll->rear->next = NULL;
	}
	free(temp);
	return key;
}

void dequeInit(dll_t *ptr_dll)
{
	init_dll(ptr_dll);
}

int dequeIsEmpty(dll_t *ptr_dll)
{
	return ptr_dll->front == NULL;
}

void dequeDisplay(dll_t *ptr_dll)
{
	display(ptr_dll);
}
