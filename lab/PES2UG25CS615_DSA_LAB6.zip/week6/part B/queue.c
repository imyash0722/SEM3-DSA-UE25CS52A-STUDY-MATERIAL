#include "queue.h"

void queueInit(queue_t *q)
{
	dequeInit(&q->d);
}

int queueIsEmpty(queue_t *q)
{
	return dequeIsEmpty(&q->d);
}

void queueEnqueue(queue_t *q, int val)
{
	insertRear(&q->d, val);
}

int queueDequeue(queue_t *q)
{
	return deleteFront(&q->d);
}

void queueDisplay(queue_t *q)
{
	dequeDisplay(&q->d);
}
