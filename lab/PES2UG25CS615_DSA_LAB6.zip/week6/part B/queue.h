#ifndef QUEUE_H
#define QUEUE_H

#include "deque.h"

struct queue {
	dll_t d;
};
typedef struct queue queue_t;

void queueInit(queue_t *q);
int queueIsEmpty(queue_t *q);
void queueEnqueue(queue_t *q, int val);
int queueDequeue(queue_t *q);
void queueDisplay(queue_t *q);

#endif
