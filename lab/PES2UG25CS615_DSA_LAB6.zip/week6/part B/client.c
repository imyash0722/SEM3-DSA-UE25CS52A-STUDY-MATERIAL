#include <stdio.h>
#include "queue.h"

int main()
{
	queue_t q;
	queueInit(&q);
	int choice;
	int val;

	printf("----- Queue (implemented using Deque) -----\n");
	printf("1. Enqueue\n");
	printf("2. Dequeue\n");
	printf("3. Display\n");
	printf("4. Exit\n");

	while(1)
	{
		printf("Enter your choice: ");
		if(scanf("%d", &choice) != 1 || choice == 4)
		{
			break;
		}
		switch(choice)
		{
			case 1:
				printf("Enter value to enqueue: ");
				scanf("%d", &val);
				queueEnqueue(&q, val);
				printf("\n");
				break;
			case 2:
				if(!queueIsEmpty(&q))
				{
					val = queueDequeue(&q);
					printf("Dequeued value: %d\n\n", val);
				}
				else
				{
					printf("Queue is empty\n\n");
				}
				break;
			case 3:
				queueDisplay(&q);
				printf("\n");
				break;
		}
	}
	return 0;
}