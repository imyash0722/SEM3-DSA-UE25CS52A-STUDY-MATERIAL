#ifndef DEQUE_H
#define DEQUE_H

struct node {
    int key;
    struct node *prev;
    struct node *next;
};
typedef struct node node_t;

struct DEQUE {
	node_t *front;
	node_t *rear;
};
typedef struct DEQUE dll_t;

void init_dll(dll_t *ptr_dll);
void deinit_dll(dll_t *ptr_dll);

void insertFront(dll_t *ptr_dll, int key);
void insertRear(dll_t* ptr_dll, int key);

void display(dll_t *ptr_dll);

int deleteFront(dll_t *ptr_dll);
int deleteRear(dll_t *ptr_dll);

void dequeInit(dll_t *ptr_dll);
int dequeIsEmpty(dll_t *ptr_dll);
void dequeDisplay(dll_t *ptr_dll);

#endif