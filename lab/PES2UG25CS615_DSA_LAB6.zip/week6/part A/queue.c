#include <stdio.h>
#include <stdlib.h>
#include "job.h"
#include "queue.h"

void init_queue(queue_t *ptr_queue)
{
	ptr_queue->front = NULL;
}

void deinit_queue(queue_t *ptr_queue)
{
	while(!is_empty(ptr_queue))
	{
		deque(ptr_queue);
	}
}

static node_t* create_node(job_t *ptr_job)
{
	node_t* temp = (node_t*)malloc(sizeof(node_t));
	if(temp == NULL)
	{
		return NULL;
	}
	temp->jobx = *ptr_job;
	temp->next = NULL;
	return temp;
}

void enque(queue_t *ptr_queue, job_t *ptr_job)
{
	if(!is_full(ptr_queue))
	{
		node_t* temp = create_node(ptr_job);
		if(ptr_queue->front == NULL || get_priority(ptr_job) > get_priority(&ptr_queue->front->jobx))
		{
			temp->next = ptr_queue->front;
			ptr_queue->front = temp;
		}
		else
		{
			node_t *pres = ptr_queue->front;
			while(pres->next != NULL && get_priority(&pres->next->jobx) >= get_priority(ptr_job))
			{
				pres = pres->next;
			}
			temp->next = pres->next;
			pres->next = temp;
		}
	}
	else
	{
		printf("queue full; cannot push\n");
	}
}

job_t deque(queue_t *ptr_queue)
{
	if(!is_empty(ptr_queue))
	{
		node_t *temp = ptr_queue->front;
		job_t joby = temp->jobx;
		ptr_queue->front = temp->next;
		free(temp);
		return joby;
	}
	else
	{
		printf("queue empty; cannot pop\n");
		exit(1);
	}
}

void display(queue_t *ptr_queue)
{
	if(!is_empty(ptr_queue))
	{
		node_t *temp = ptr_queue->front;
		printf("\nJobID   Depth   Traffic   Priority\n");
		printf("---------------------------------------\n");
		while(temp != NULL)
		{
			disp_job(&temp->jobx);
			temp = temp->next;
		}
		printf("\n");
	}
	else
	{
		printf("queue empty\n");
	}
}

int is_full(queue_t *ptr_queue)
{
	node_t* temp = (node_t*)malloc(sizeof(node_t));
	if(temp == NULL)
	{
		return 1;
	}
	free(temp);
	return 0;
}

int is_empty(queue_t *ptr_queue)
{
	return ptr_queue->front == NULL;
}