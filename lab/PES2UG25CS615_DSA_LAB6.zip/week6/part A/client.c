#include <stdio.h>
#include "job.h"
#include "queue.h"

int main()
{
	queue_t q;
	init_queue(&q);
	int choice;
	job_t jobx;
	int depth, traffic;
	int job_no = 1;

	printf("----- Pothole Repair Priority Queue -----\n");
	printf("1. Add Pothole Job (Enqueue)\n");
	printf("2. Process Highest Priority Job (Dequeue)\n");
	printf("3. Display All Pending Jobs\n");
	printf("4. Exit\n");

	while(1)
	{
		printf("Enter your choice: ");
		if(scanf("%d", &choice) != 1 || choice == 4)
		{
			break;
		}
		switch(choice)
		{
			case 1:
				printf("Enter pothole depth (1-5): ");
				scanf("%d", &depth);
				printf("Enter traffic heaviness (1-5): ");
				scanf("%d", &traffic);
				set_job(&jobx, job_no, depth, traffic);
				enque(&q, &jobx);
				printf("Job %d added with priority %d.\n\n", job_no, get_priority(&jobx));
				job_no++;
				break;
			case 2:
				if(!is_empty(&q))
				{
					jobx = deque(&q);
					printf("Processing Job %d (Depth=%d, Traffic=%d, Priority=%d)\n\n", jobx.job_no, jobx.depth, jobx.traffic, jobx.priority);
				}
				else
				{
					printf("Queue is empty\n\n");
				}
				break;
			case 3:
				display(&q);
				break;
		}
	}
	deinit_queue(&q);
	return 0;
}