#include <stdio.h>
#include "job.h"

void set_job(job_t* ptr_job, int job_no, int depth, int traffic)
{
	ptr_job->job_no = job_no;
	ptr_job->depth = depth;
	ptr_job->traffic = traffic;
	ptr_job->priority = depth + traffic;
}

void disp_job(job_t* ptr_job)
{
	printf("%-8d%-8d%-10d%d\n", ptr_job->job_no, ptr_job->depth, ptr_job->traffic, ptr_job->priority);
}

int get_priority(job_t* ptr_job)
{
	return ptr_job->priority;
}