#include <stdio.h>
#include "deque.h"

int main(void)
{
    int k;
    int n;
    int value;
    int i;

    printf("Enter window size K: ");
    scanf("%d", &k);

    if (k <= 0)
    {
        printf("Invalid window size\n");
        return 1;
    }

    printf("Enter number of package weights: ");
    scanf("%d", &n);

    if (n <= 0)
    {
        printf("Invalid number of readings\n");
        return 1;
    }

    initializeDeque(k);

    printf("Window minimum after each reading:\n");
    for (i = 0; i < n; i++)
    {
        scanf("%d", &value);
        addPackageWeight(value);
    }

    freeDeque();
    return 0;
}
