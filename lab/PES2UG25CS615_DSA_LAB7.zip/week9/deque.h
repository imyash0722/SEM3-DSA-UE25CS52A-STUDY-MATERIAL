#ifndef DEQUE_H
#define DEQUE_H

void initializeDeque(int k);
void addPackageWeight(int value);
void freeDeque(void);

#endif
