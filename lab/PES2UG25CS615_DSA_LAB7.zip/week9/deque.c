#include <stdio.h>
#include <stdlib.h>
#include "deque.h"

static int *values = NULL;
static int *indices = NULL;
static int capacity = 0;
static int front = 0;
static int rear = -1;
static int count = 0;
static int windowSize = 0;
static int currentIndex = 0;

void initializeDeque(int k)
{
    windowSize = k;
    capacity = k;
    values = (int *)malloc((size_t)capacity * sizeof(int));
    indices = (int *)malloc((size_t)capacity * sizeof(int));
    front = 0;
    rear = -1;
    count = 0;
    currentIndex = 0;
}

void addPackageWeight(int value)
{
    while (count > 0 && indices[front] <= currentIndex - windowSize)
    {
        front = (front + 1) % capacity;
        count--;
    }

    while (count > 0 && values[rear] >= value)
    {
        rear = (rear - 1 + capacity) % capacity;
        count--;
    }

    if (count == 0)
    {
        front = 0;
        rear = -1;
    }

    rear = (rear + 1) % capacity;
    values[rear] = value;
    indices[rear] = currentIndex;
    count++;

    printf("%d\n", values[front]);
    currentIndex++;
}

void freeDeque(void)
{
    free(values);
    free(indices);
    values = NULL;
    indices = NULL;
    capacity = 0;
    front = 0;
    rear = -1;
    count = 0;
    windowSize = 0;
    currentIndex = 0;
}
