#include <stdio.h>
#include <stdlib.h>
#include "heap.h"

void init(heap_t *ptr_heap, int (*cmp)(int, int))
{
	ptr_heap->n = 0;
	ptr_heap->cmp = cmp;
}

void deinit(heap_t *ptr_heap)
{
	ptr_heap->n = 0;
	ptr_heap->cmp = NULL;
}

void disp(heap_t *ptr_heap)
{
	for(int i = 1; i <= ptr_heap->n; ++i)
	{
		printf("%d ", ptr_heap->key[i]);
	}
	printf("\n");
}

static void heapify(int a[], int n, int pos, int (*cmp)(int, int))
{
	int i = pos;
	int j = 2 * i;
	int val = a[i];
	int is_heap = 0;
	while(j <= n && !is_heap)
	{
		if(j + 1 <= n && cmp(a[j+1], a[j]))
			++j;
		if(cmp(a[j], val))
		{
			a[i] = a[j];
			i = j;
			j = 2 * i;
		}
		else 
		{
			is_heap = 1;
		}
	}
	a[i] = val;
}

static void swap(int *p, int *q)
{
	int temp = *p;
	*p = *q;
	*q = temp;
}

void insert(heap_t *ptr_heap, int key)
{
	// add at the end
	// heapify upwards 
	int pos = ++ptr_heap->n;
	if(pos >= MAXSIZE)
	{
		printf("heap full\n");
		exit(1);
	}
	ptr_heap->key[pos] = key;
	while(pos > 1 && ptr_heap->cmp(ptr_heap->key[pos], ptr_heap->key[pos/2]))
	{
		swap(&ptr_heap->key[pos], &ptr_heap->key[pos/2]);
		pos = pos / 2;
	}
}

int delete_root(heap_t *ptr_heap)
{
	if(ptr_heap->n == 0)
	{
		printf("heap empty\n");
		exit(1);
	}
	int res = ptr_heap->key[1];
	ptr_heap->key[1] = ptr_heap->key[ptr_heap->n];
	
	heapify(ptr_heap->key, --ptr_heap->n, 1, ptr_heap->cmp);
	return res;
}

int peek_root(heap_t *ptr_heap)
{
	if(ptr_heap->n == 0)
	{
		printf("heap empty\n");
		exit(1);
	}
	return ptr_heap->key[1];
}

int delete_max(heap_t *ptr_heap)
{
	return delete_root(ptr_heap);
}

int peek_max(heap_t *ptr_heap)
{
	return peek_root(ptr_heap);
}

void build_heap(heap_t *ptr_heap, int a[], int n)
{
	for(int i = 0; i < n; ++i)
	{
		ptr_heap->key[i + 1] = a[i];
	}
	ptr_heap->n = n;
	for(int i = n / 2; i >= 1; --i)
	{
		heapify(ptr_heap->key, ptr_heap->n, i, ptr_heap->cmp);
	}
}
