#include <stdio.h>
#include <stdlib.h>
#include "heap.h"

int max_compare(int a, int b)
{
	return a > b;
}

int min_compare(int a, int b)
{
	return a < b;
}

void print_both_trees(heap_t *left, heap_t *right)
{
	printf("Left Tree  (Max-Heap): ");
	disp(left);
	printf("Right Tree (Min-Heap): ");
	disp(right);
}

void insert_running_median(heap_t *left, heap_t *right, int x)
{
	// a. if left is null (intial condition when both the trees is empty by default insert in left) - insert new node in left
	// b. if left is not null and new key to be inserted is less than or equal to left root then insert into left heap else insert in right heap
	if(left->n == 0)
	{
		insert(left, x);
	}
	else if(x <= peek_root(left))
	{
		insert(left, x);
	}
	else
	{
		insert(right, x);
	}

	// c. after insertion check size of both trees and perform following according to condition
	//    - if size(left) > size(right)+1 then delete root from left and insert into right
	//    - if size(right) > size(left) then delete root from right and insert into left
	if(left->n > right->n + 1)
	{
		int temp = delete_root(left);
		insert(right, temp);
	}
	else if(right->n > left->n)
	{
		int temp = delete_root(right);
		insert(left, temp);
	}

	// d. print both the trees
	print_both_trees(left, right);

	// e. find median 
	//    - if size(left) == size(right) then median = root(left)+root(right)/2
	//      else
	//         median = root(left)
	if(left->n == right->n)
	{
		double median = (peek_root(left) + peek_root(right)) / 2.0;
		if((int)median == median)
		{
			printf("Median: %d\n", (int)median);
		}
		else
		{
			printf("Median: %.1f\n", median);
		}
	}
	else
	{
		int median = peek_root(left);
		printf("Median: %d\n", median);
	}
}

int main()
{
	heap_t left;   // Max-heap for lower half
	heap_t right;  // Min-heap for upper half

	init(&left, max_compare);
	init(&right, min_compare);

	int opt;
	int val;
	printf("opt : 1 insert; 2 : run demo; 0 : exit : ");
	while(scanf("%d", &opt) == 1 && opt != 0)
	{
		switch(opt)
		{
			case 1:
				printf("Enter the the value: ");
				if(scanf("%d", &val) == 1)
				{
					insert_running_median(&left, &right, val);
				}
				break;
			case 2:
			{
				int demo[] = {5, 15, 1, 3, 2, 8, 7, 9, 10, 6, 11, 4};
				int n = sizeof(demo) / sizeof(demo[0]);
				printf("\n--- Running Demo with Sequence: 5, 15, 1, 3, 2, 8, 7, 9, 10, 6, 11, 4 ---\n");
				for(int i = 0; i < n; ++i)
				{
					printf("\n--> Inserting %d:\n", demo[i]);
					insert_running_median(&left, &right, demo[i]);
				}
				break;
			}
			default:
				printf("Invalid option\n");
				break;
		}
		printf("\nopt : 1 insert; 2 : run demo; 0 : exit : ");
	}

	deinit(&left);
	deinit(&right);
	return 0;
}
