#include <stdio.h>
#include "heap.h"

int max_compare(int a, int b)
{
	return a > b;
}

int min_compare(int a, int b)
{
	return a < b;
}

int main()
{
	heap_t h;
	int choice;
	printf("Select heap type: 1 for Max Heap, 2 for Min Heap: ");
	if(scanf("%d", &choice) != 1)
	{
		return 0;
	}

	if(choice == 2)
	{
		init(&h, min_compare);
		printf("Min-Heap initialized.\n");
	}
	else
	{
		init(&h, max_compare);
		printf("Max-Heap initialized.\n");
	}

	int opt;
	int key;
	printf("opt : 1 insert; 2 : delete; 0 : exit : ");
	while(scanf("%d", &opt) == 1 && opt != 0)
	{
		switch(opt)
		{
			case 1 : 	printf("Enter the the value: ");
						scanf("%d", &key);
						insert(&h, key);
						disp(&h);
						break;
			case 2 : 	key = delete_root(&h);
						printf("deleted : %d\n", key);
						disp(&h);
						break;
			default:
						printf("Invalid option\n");
						break;
		}
		
		printf("opt : 1 insert; 2 : delete; 0 : exit : ");
	}
	deinit(&h);
	return 0;
}