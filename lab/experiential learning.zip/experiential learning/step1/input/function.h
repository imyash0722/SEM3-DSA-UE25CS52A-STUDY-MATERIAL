#ifndef FUNCTION_H 
#define FUNCTION_H 

void mymap(int a[], int b[], int n, int (*op)(int));  //call op function for every element of a and store result in b

void myfilter(int a[], int n, int b[], int *ptr_m, int (*op)(int));

int myreduce(int a[], int n, int init, int (*op)(int,int));
#endif 