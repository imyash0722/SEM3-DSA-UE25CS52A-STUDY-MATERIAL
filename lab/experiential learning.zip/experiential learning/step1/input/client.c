#include <stdio.h> 
#include "function.h" 

int sq(int x) 
{ 
 return x * x; 
}

int odd_number(int x)
{
	return x%2!=0;
}

int sum(int n,int ele)
{
	return n+ele;
}

 
void disp(int a[], int n)
{
	for(int i = 0; i < n; ++i)
	{
		printf("%d ", a[i]);
	}
	printf("\n");
}

int main()
{
	int a[] = {1, 2, 3, 4, 5};
	int n = 5;
	int b[5];
	mymap(a, b, n, sq);
	disp(a, n);
	disp(b, n);
	
	int num;
	myfilter(a,n,b,&num,odd_number);
	printf("Printing odd numbers of array \n");
	disp(b, num);

	printf("Sum of elements of array: %d ",myreduce(a,n,0,sum));
	
}