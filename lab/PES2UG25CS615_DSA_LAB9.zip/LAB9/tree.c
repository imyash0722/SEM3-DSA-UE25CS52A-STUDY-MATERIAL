#include <stdio.h>
#include <stdlib.h>
#include "tree.h"
#include "queue.h"

struct canvas
{
	char **grid;
	int rows;
	int cols;
	int cell_width;
	int pos;
};
typedef struct canvas canvas_t;

static void disp_recursive(tree_node_t *temp)
{
	if (temp)
	{
		disp_recursive(temp->left_);
		printf("%d ", temp->key_);
		disp_recursive(temp->right_);
	}
}

static tree_node_t* insert_recursive(tree_node_t *root, tree_node_t *temp)
{
	if (root == NULL)
	{
		root = temp;
	}
	else if (root->key_ > temp->key_)
	{
		root->left_ = insert_recursive(root->left_, temp);
	}
	else
	{
		root->right_ = insert_recursive(root->right_, temp);
	}
	return root;
}

static void deinit_recursive(tree_node_t *root)
{
	if (root)
	{
		deinit_recursive(root->left_);
		deinit_recursive(root->right_);
		free(root);
	}
}

static int height_recursive(tree_node_t *root)
{
	if (root == NULL)
	{
		return 0;
	}
	int lh = height_recursive(root->left_);
	int rh = height_recursive(root->right_);
	return (lh > rh ? lh : rh) + 1;
}

static int count_recursive(tree_node_t *root)
{
	if (root == NULL)
	{
		return 0;
	}
	return 1 + count_recursive(root->left_) + count_recursive(root->right_);
}

static int max_width_recursive(tree_node_t *root)
{
	if (root == NULL)
	{
		return 0;
	}
	char buf[32];
	int w = snprintf(buf, sizeof(buf), "%d", root->key_);
	int lw = max_width_recursive(root->left_);
	int rw = max_width_recursive(root->right_);
	if (lw > w)
	{
		w = lw;
	}
	if (rw > w)
	{
		w = rw;
	}
	return w;
}

static int place(tree_node_t *root, int depth, canvas_t *cv)
{
	int left_col = -1;
	int right_col = -1;
	if (root->left_ != NULL)
	{
		left_col = place(root->left_, depth + 1, cv);
	}
	int col = cv->pos * cv->cell_width;
	cv->pos++;
	char buf[32];
	int len = snprintf(buf, sizeof(buf), "%d", root->key_);
	for (int i = 0; i < len; ++i)
	{
		cv->grid[2 * depth][col + i] = buf[i];
	}
	if (root->right_ != NULL)
	{
		right_col = place(root->right_, depth + 1, cv);
	}
	if (root->left_ != NULL || root->right_ != NULL)
	{
		int start = (left_col != -1) ? left_col : col;
		int end = (right_col != -1) ? right_col : col;
		for (int c = start; c <= end; ++c)
		{
			cv->grid[2 * depth + 1][c] = '-';
		}
		cv->grid[2 * depth + 1][col] = '+';
		if (left_col != -1)
		{
			cv->grid[2 * depth + 1][left_col] = '+';
		}
		if (right_col != -1)
		{
			cv->grid[2 * depth + 1][right_col] = '+';
		}
	}
	return col;
}

void init(tree_t *ptr_tree)
{
	ptr_tree->root_ = NULL;
}

void deinit(tree_t *ptr_tree)
{
	deinit_recursive(ptr_tree->root_);
	ptr_tree->root_ = NULL;
}

void disp(tree_t *ptr_tree)
{
	printf("Tree : ");
	disp_recursive(ptr_tree->root_);
	printf("\n");
}

void insert(tree_t *ptr_tree, int key)
{
	tree_node_t *temp = (tree_node_t*)malloc(sizeof(tree_node_t));
	temp->key_ = key;
	temp->left_ = temp->right_ = NULL;
	ptr_tree->root_ = insert_recursive(ptr_tree->root_, temp);
}

void level_order(tree_t *ptr_tree)
{
	queue_t q;
	init_queue(&q);
	printf("Level order : ");
	enqueue(&q, ptr_tree->root_);
	while (!is_empty(&q))
	{
		tree_node_t *temp = dequeue(&q);
		if (temp != NULL)
		{
			printf("%d ", temp->key_);
			enqueue(&q, temp->left_);
			enqueue(&q, temp->right_);
		}
	}
	printf("\n");
	deinit_queue(&q);
}

void level_order_lines(tree_t *ptr_tree)
{
	if (ptr_tree->root_ == NULL)
	{
		printf("(empty tree)\n");
		return;
	}
	queue_t q;
	init_queue(&q);
	enqueue(&q, ptr_tree->root_);
	int cur = 1, next = 0, level = 0, printed = 0;
	while (!is_empty(&q))
	{
		tree_node_t *temp = dequeue(&q);
		--cur;
		if (temp != NULL)
		{
			if (printed == 0)
			{
				printf("  Level %d : ", level);
			}
			printf("%4d", temp->key_);
			++printed;
			enqueue(&q, temp->left_);
			enqueue(&q, temp->right_);
			next += 2;
		}
		if (cur == 0)
		{
			if (printed > 0)
			{
				printf("\n");
				++level;
			}
			cur = next;
			next = 0;
			printed = 0;
		}
	}
	deinit_queue(&q);
}

void disp_tree(tree_t *ptr_tree)
{
	if (ptr_tree->root_ == NULL)
	{
		printf("(empty tree)\n");
		return;
	}
	int h = height_recursive(ptr_tree->root_);
	int n = count_recursive(ptr_tree->root_);
	int w = max_width_recursive(ptr_tree->root_);
	canvas_t cv;
	cv.cell_width = w + 2;
	cv.rows = 2 * h - 1;
	cv.cols = n * cv.cell_width;
	cv.pos = 0;
	cv.grid = (char**)malloc(cv.rows * sizeof(char*));
	for (int r = 0; r < cv.rows; ++r)
	{
		cv.grid[r] = (char*)malloc((cv.cols + 1) * sizeof(char));
		for (int c = 0; c < cv.cols; ++c)
		{
			cv.grid[r][c] = ' ';
		}
		cv.grid[r][cv.cols] = '\0';
	}
	place(ptr_tree->root_, 0, &cv);
	for (int r = 0; r < cv.rows; ++r)
	{
		int end = cv.cols - 1;
		while (end >= 0 && cv.grid[r][end] == ' ')
		{
			cv.grid[r][end] = '\0';
			--end;
		}
		printf("  %s\n", cv.grid[r]);
		free(cv.grid[r]);
	}
	free(cv.grid);
}
