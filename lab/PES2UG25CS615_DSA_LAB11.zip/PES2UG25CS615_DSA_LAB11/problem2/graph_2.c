#include <stdio.h>
#include "graph_2.h"

static void dfs_recursive(int n_vertices, int adj_mat[][MAXSIZE], int *visited, int v)
{
	visited[v] = 1;
	for (int i = 0; i < n_vertices; ++i)
	{
		if (adj_mat[v][i] && !visited[i])
		{
			dfs_recursive(n_vertices, adj_mat, visited, i);
		}
	}
}

void init_graph(graph_t *ptr_graph, int n_vertices, int n_edges)
{
	ptr_graph->n_vertices_ = n_vertices;
	ptr_graph->n_edges_ = n_edges;
	for (int i = 0; i < n_vertices; ++i)
	{
		for (int j = 0; j < n_vertices; ++j)
		{
			ptr_graph->adj_mat_[i][j] = 0;
		}
	}
}

void deinit_graph(graph_t *ptr_graph)
{
	for (int i = 0; i < ptr_graph->n_vertices_; ++i)
	{
		for (int j = 0; j < ptr_graph->n_vertices_; ++j)
		{
			ptr_graph->adj_mat_[i][j] = 0;
		}
	}
	ptr_graph->n_vertices_ = 0;
	ptr_graph->n_edges_ = 0;
}

void add_edge(graph_t *ptr_graph, int u, int v)
{
	ptr_graph->adj_mat_[u][v] = 1;
	ptr_graph->adj_mat_[v][u] = 1;
}

void remove_edge(graph_t *ptr_graph, int u, int v)
{
	ptr_graph->adj_mat_[u][v] = 0;
	ptr_graph->adj_mat_[v][u] = 0;
}

void disp(graph_t *ptr_graph)
{
	printf("  ");
	for (int j = 0; j < ptr_graph->n_vertices_; ++j)
	{
		printf("%c ", j + 'A');
	}
	printf("\n");
	for (int i = 0; i < ptr_graph->n_vertices_; ++i)
	{
		printf("%c ", i + 'A');
		for (int j = 0; j < ptr_graph->n_vertices_; ++j)
		{
			printf("%d ", ptr_graph->adj_mat_[i][j]);
		}
		printf("\n");
	}
}

int to_visit(int *visited, int n_vertices)
{
	for (int i = 0; i < n_vertices; ++i)
	{
		if (visited[i] == 0)
		{
			return i;
		}
	}
	return -1;
}

void dfs(graph_t *ptr_graph, int v)
{
	int visited[MAXSIZE];
	for (int i = 0; i < ptr_graph->n_vertices_; ++i)
	{
		visited[i] = 0;
	}
	dfs_recursive(ptr_graph->n_vertices_, ptr_graph->adj_mat_, visited, v);
}

int connected_components(graph_t *ptr_graph)
{
	int visited[MAXSIZE];
	for (int i = 0; i < ptr_graph->n_vertices_; ++i)
	{
		visited[i] = 0;
	}
	int count = 0;
	int u = to_visit(visited, ptr_graph->n_vertices_);
	while (u != -1)
	{
		++count;
		dfs_recursive(ptr_graph->n_vertices_, ptr_graph->adj_mat_, visited, u);
		u = to_visit(visited, ptr_graph->n_vertices_);
	}
	return count;
}

int connect_components(graph_t *ptr_graph)
{
	int visited[MAXSIZE];
	int reps[MAXSIZE];
	int k = 0;
	for (int i = 0; i < ptr_graph->n_vertices_; ++i)
	{
		visited[i] = 0;
	}
	int u = to_visit(visited, ptr_graph->n_vertices_);
	while (u != -1)
	{
		reps[k++] = u;
		dfs_recursive(ptr_graph->n_vertices_, ptr_graph->adj_mat_, visited, u);
		u = to_visit(visited, ptr_graph->n_vertices_);
	}
	printf("Components = %d, connections needed = %d\n", k, k > 0 ? k - 1 : 0);
	for (int i = 0; i + 1 < k; ++i)
	{
		printf("Connect %c - %c\n", reps[i] + 'A', reps[i + 1] + 'A');
		add_edge(ptr_graph, reps[i], reps[i + 1]);
		ptr_graph->n_edges_++;
	}
	return k > 0 ? k - 1 : 0;
}
