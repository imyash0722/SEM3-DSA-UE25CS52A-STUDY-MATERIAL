#ifndef GRAPH2_H
#define GRAPH2_H

#define MAXSIZE 20

struct graph
{
	int n_vertices_;
	int n_edges_;
	int adj_mat_[MAXSIZE][MAXSIZE];
};
typedef struct graph graph_t;

void init_graph(graph_t *ptr_graph, int n_vertices, int n_edges);
void deinit_graph(graph_t *ptr_graph);
void add_edge(graph_t *ptr_graph, int u, int v);
void remove_edge(graph_t *ptr_graph, int u, int v);
void disp(graph_t *ptr_graph);
int to_visit(int *visited, int n_vertices);
void dfs(graph_t *ptr_graph, int v);
int connected_components(graph_t *ptr_graph);
int connect_components(graph_t *ptr_graph);

#endif
