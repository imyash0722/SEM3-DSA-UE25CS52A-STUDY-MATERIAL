#ifndef GRAPH_H
#define GRAPH_H

#define MAXSIZE 20

struct node
{
	int v_;
	struct node *next_;
};
typedef struct node node_t;

struct graph
{
	int n_vertices_;
	int n_edges_;
	node_t *adj_list_[MAXSIZE];
};
typedef struct graph graph_t;

void init_graph(graph_t *ptr_graph, int n_vertices, int n_edges);
void deinit_graph(graph_t *ptr_graph);
void add_edge(graph_t *ptr_graph, int u, int v);
void disp(graph_t *ptr_graph);

#endif
