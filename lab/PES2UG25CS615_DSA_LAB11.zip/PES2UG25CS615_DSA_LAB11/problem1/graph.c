#include <stdio.h>
#include <stdlib.h>
#include "graph.h"

static node_t* create_node(int v)
{
	node_t *temp = (node_t*)malloc(sizeof(node_t));
	temp->v_ = v;
	temp->next_ = NULL;
	return temp;
}

static node_t* insert_end(node_t *head, int v)
{
	node_t *temp = create_node(v);
	if (head == NULL)
	{
		return temp;
	}
	node_t *cur = head;
	while (cur->next_ != NULL)
	{
		cur = cur->next_;
	}
	cur->next_ = temp;
	return head;
}

static void free_list(node_t *head)
{
	while (head != NULL)
	{
		node_t *temp = head;
		head = head->next_;
		free(temp);
	}
}

void init_graph(graph_t *ptr_graph, int n_vertices, int n_edges)
{
	ptr_graph->n_vertices_ = n_vertices;
	ptr_graph->n_edges_ = n_edges;
	for (int i = 0; i < n_vertices; ++i)
	{
		ptr_graph->adj_list_[i] = NULL;
	}
}

void deinit_graph(graph_t *ptr_graph)
{
	for (int i = 0; i < ptr_graph->n_vertices_; ++i)
	{
		free_list(ptr_graph->adj_list_[i]);
		ptr_graph->adj_list_[i] = NULL;
	}
	ptr_graph->n_vertices_ = 0;
	ptr_graph->n_edges_ = 0;
}

void add_edge(graph_t *ptr_graph, int u, int v)
{
	ptr_graph->adj_list_[u] = insert_end(ptr_graph->adj_list_[u], v);
	ptr_graph->adj_list_[v] = insert_end(ptr_graph->adj_list_[v], u);
}

void disp(graph_t *ptr_graph)
{
	for (int i = 0; i < ptr_graph->n_vertices_; ++i)
	{
		printf("%c :", i + 'A');
		node_t *temp = ptr_graph->adj_list_[i];
		while (temp != NULL)
		{
			printf(" %d", temp->v_);
			temp = temp->next_;
		}
		printf("\n");
	}
}
