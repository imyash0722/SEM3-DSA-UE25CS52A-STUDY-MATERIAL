#include "graph.h"

int main(void)
{
	graph_t g;
	init_graph(&g, 8, 6);
	add_edge(&g, 0, 1);
	add_edge(&g, 1, 2);
	add_edge(&g, 3, 4);
	add_edge(&g, 5, 6);
	disp(&g);
	deinit_graph(&g);
	return 0;
}
