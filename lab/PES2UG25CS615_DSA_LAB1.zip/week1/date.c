#include "date.h"
#include <stdio.h>

void set(date *d) { scanf("%d-%d-%d", &d->date, &d->month, &d->year); }

void disp(date *d) { printf("%d-%d-%d\n", d->date, d->month, d->year); }
