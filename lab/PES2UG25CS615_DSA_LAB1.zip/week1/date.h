typedef struct date {
  int date;
  int year;
  int month;
} date;

void set(date *d);
void disp(date *d);