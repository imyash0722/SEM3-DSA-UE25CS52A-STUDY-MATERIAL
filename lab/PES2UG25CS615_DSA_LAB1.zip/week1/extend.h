#include "event.h"
#include <stdio.h>

int read_all(FILE *fp, event arr[]);
void disp_all(event arr[], int count);
void sort_events(event arr[], int count);
event latest(event arr[], int count);