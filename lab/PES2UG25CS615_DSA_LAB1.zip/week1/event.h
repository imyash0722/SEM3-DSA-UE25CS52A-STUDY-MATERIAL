#include "date.h"

typedef struct event {
  char detail[100];
  date event_date;
} event;

void set_event(event *e);
void disp_event(event *e);