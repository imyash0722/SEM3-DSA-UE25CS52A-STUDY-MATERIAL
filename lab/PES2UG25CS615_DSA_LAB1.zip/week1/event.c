#include "event.h"
#include <stdio.h>

void set_event(event *e) {
  printf("Enter event description: ");
  scanf("%s", e->detail);

  printf("Enter event date details:\n");
  set(&(e->event_date));
}

void disp_event(event *e) {
  printf("Event: %s\n", e->detail);
  printf("Date:  ");
  disp(&(e->event_date));
}
