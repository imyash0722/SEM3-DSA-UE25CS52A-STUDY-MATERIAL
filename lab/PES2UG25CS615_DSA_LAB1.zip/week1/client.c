#include "extend.h"
#include <stdio.h>

int main() {
  event arr[200];
  FILE *f = fopen("event.txt", "r");

  int count = read_all(f, arr);

  disp_all(arr, count);

  event l_event = latest(arr, count);

  printf("\n--- After Sorting ---\n");
  disp_all(arr, count);

  printf("\nLatest Event : %s ; Date : %d-%d-%d\n", l_event.detail,
         l_event.event_date.date, l_event.event_date.month,
         l_event.event_date.year);

  fclose(f);
}
