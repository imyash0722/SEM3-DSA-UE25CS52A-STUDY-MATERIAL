#include "extend.h"
#include <stdio.h>

int read_all(FILE *fp, event arr[]) {

  char buffer[500];
  int count = 0;

  while (fgets(buffer, sizeof(buffer), fp) != NULL) {

    sscanf(buffer, "%d-%d-%d %s", &(arr[count].event_date.date),
           &(arr[count].event_date.month), &(arr[count].event_date.year),
           arr[count].detail);
    count++;
  }

  return count;
}

void disp_all(event arr[], int count) {

  for (int i = 0; i < count; i++) {

    printf("Event : %s ; Date : %d-%d-%d\n", arr[i].detail,
           arr[i].event_date.date, arr[i].event_date.month,
           arr[i].event_date.year);
  }
  printf("\n No : of Event = %d\n", count);
}

event latest(event arr[], int count) {

  sort_events(arr, count);
  return arr[count - 1];
}

void sort_events(event arr[], int count) {
  for (int i = 0; i < count - 1; i++) {
    for (int j = 0; j < count - i - 1; j++) {

      int swap = 0;

      if (arr[j].event_date.year > arr[j + 1].event_date.year) {
        swap = 1;

      }

      else if (arr[j].event_date.year == arr[j + 1].event_date.year) {

        if (arr[j].event_date.month > arr[j + 1].event_date.month) {
          swap = 1;
        }

        else if (arr[j].event_date.month == arr[j + 1].event_date.month) {

          if (arr[j].event_date.date > arr[j + 1].event_date.date) {
            swap = 1;
          }
        }
      }

      if (swap) {
        event temp = arr[j];
        arr[j] = arr[j + 1];
        arr[j + 1] = temp;
      }
    }
  }
}