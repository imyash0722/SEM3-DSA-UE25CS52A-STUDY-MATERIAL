#include "list.h"
#include <stdio.h>
#include <stdlib.h>

void init_list(mylist_t *ptr_list) { ptr_list->head_ = NULL; }

void insert_list(mylist_t *ptr_list, int l, int b) {

  node_t *temp = (node_t *)malloc(sizeof(node_t));
  set_rect(&(temp->key_), l, b);
  temp->next_ = NULL;

  if (ptr_list->head_ == NULL) {
    ptr_list->head_ = temp;
    temp->next_ = NULL;
  }

  else {

    node_t *prev = NULL;
    node_t *pres = ptr_list->head_;

    while (pres != NULL && compare_rect(&(pres->key_), &(temp->key_))) {
      prev = pres;
      pres = pres->next_;
    }

    if (prev == NULL) // insert in the beginning
    {
      temp->next_ = pres;
      ptr_list->head_ = temp;
    }

    else // middle or end
    {
      temp->next_ = pres;
      prev->next_ = temp;
    }
  }
}

void disp_(node_t *q) {

  while (q != NULL) {

    disp_rect(&(q->key_));
    printf("\n Area: %d\n", area_rect(&(q->key_)));
    q = q->next_;
  }
}

void disp_list(mylist_t *ptr_list) { disp_(ptr_list->head_); }

void free_list_(node_t *q) {
  node_t *r;
  while (q != NULL) {
    r = q->next_;
    free(q);
    q = r;
  }
}

void free_list(mylist_t *ptr_list) { free_list_(ptr_list->head_); }

int total_area_list(mylist_t *ptr_list) {
  int total = 0;
  node_t *q = ptr_list->head_;
  while (q != NULL) {
    total += area_rect(&(q->key_));
    q = q->next_;
  }
  return total;
}

rect* highest_length_site(mylist_t *ptr_list) {
  if (ptr_list->head_ == NULL) return NULL;
  node_t *q = ptr_list->head_;
  rect *max_len_rect = &(q->key_);
  while (q != NULL) {
    if (q->key_.length > max_len_rect->length) {
      max_len_rect = &(q->key_);
    }
    q = q->next_;
  }
  return max_len_rect;
}

rect* least_breadth_site(mylist_t *ptr_list) {
  if (ptr_list->head_ == NULL) return NULL;
  node_t *q = ptr_list->head_;
  rect *min_breadth_rect = &(q->key_);
  while (q != NULL) {
    if (q->key_.breadth < min_breadth_rect->breadth) {
      min_breadth_rect = &(q->key_);
    }
    q = q->next_;
  }
  return min_breadth_rect;
}
