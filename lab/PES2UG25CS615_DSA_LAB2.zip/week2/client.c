#include "list.h"
#include <stdio.h>

int main() {

  mylist_t l;
  init_list(&l);

  int n;
  printf("Enter number of rectangles: ");
  scanf("%d", &n);

  for (int i = 0; i < n; ++i) {

    int length, breadth;
    printf("Enter length and breadth for rectangle %d: ", i + 1);

    scanf("%d %d", &length, &breadth);

    insert_list(&l, length, breadth);
  }

  printf("\nList of Rectangles (Sorted by Area)\n");
  disp_list(&l);

  int unit_value;
  printf("\nEnter the value of a unit area: ");
  scanf("%d", &unit_value);
  int total_area = total_area_list(&l);
  printf("Total layout value: %d\n", total_area * unit_value);

  rect *max_len = highest_length_site(&l);
  if (max_len != NULL) {
    printf("\nSite with highest length:");
    disp_rect(max_len);
    printf("\n");
  }

  rect *min_breadth = least_breadth_site(&l);
  if (min_breadth != NULL) {
    printf("\nSite with least breadth:");
    disp_rect(min_breadth);
    printf("\n");
  }

  free_list(&l);
  return 0;
}
