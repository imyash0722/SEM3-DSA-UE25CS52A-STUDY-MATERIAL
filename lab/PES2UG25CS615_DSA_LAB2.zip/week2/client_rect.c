#include "rect.h"
#include <stdio.h>

int main() {
  rect r;
  int l, b;

  printf("Enter length and breadth of rectangle: ");
  scanf("%d %d", &l, &b);

  set_rect(&r, l, b);
  disp_rect(&r);
  printf("\n Area of Rectangle is : %d\n", area_rect(&r));

  return 0;
}
