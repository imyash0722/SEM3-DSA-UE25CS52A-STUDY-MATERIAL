typedef struct rect {

  int length;
  int breadth;

} rect;

void set_rect(rect *, int l, int b);
void disp_rect(rect *);
int area_rect(rect *);
int compare_rect(rect *, rect *);
