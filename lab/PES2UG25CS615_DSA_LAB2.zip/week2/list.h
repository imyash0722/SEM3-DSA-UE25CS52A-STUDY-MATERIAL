#include "rect.h"

struct node {
  rect key_;
  struct node *next_;
};
typedef struct node node_t;

struct mylist {
  node_t *head_;
};
typedef struct mylist mylist_t;

void init_list(mylist_t *);
void insert_list(mylist_t *, int l, int b);
void disp_list(mylist_t *);
void free_list(mylist_t *);

int total_area_list(mylist_t *);
rect* highest_length_site(mylist_t *);
rect* least_breadth_site(mylist_t *);
