#include "rect.h"
#include <stdio.h>

void set_rect(rect *a, int l, int b) {

  a->length = l;
  a->breadth = b;
}

void disp_rect(rect *a) {

  printf("\n Length of Rectangle is : %d", a->length);
  printf("\n Breadth of Rectangle is : %d", a->breadth);
}

int area_rect(rect *a) { return a->length * a->breadth; }

int compare_rect(rect *a, rect *b) {
  return area_rect(a) < area_rect(b);
}
