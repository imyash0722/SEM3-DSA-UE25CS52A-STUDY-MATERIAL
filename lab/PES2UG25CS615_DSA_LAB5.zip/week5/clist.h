#ifndef clist_H
#define clist_H

struct node {
  char name[25];
  struct node *next;
};
typedef struct node node_t;

struct clist {
  node_t *head;
};
typedef struct clist clist_t;

void init_clist(clist_t *);
void insert_end(clist_t *ptr_clist, const char *name);
char *delete_beg(clist_t *ptr_clist);
void find_kth(clist_t *ptr_clist, int k);
void disp_list(clist_t *ptr_clist);
void free_clist(clist_t *);

#endif
