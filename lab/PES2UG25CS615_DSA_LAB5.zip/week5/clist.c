#include "clist.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void init_clist(clist_t *ptr_clist) { 
  ptr_clist->head = NULL;
}

static node_t *create_node(const char *name) {
  node_t *temp;
  temp = (node_t *)malloc(sizeof(node_t));
  if (temp == NULL) {
    printf("Memory allocation failed\n");
    exit(1);
  }
  strcpy(temp->name, name);
  temp->next = NULL;
  return temp;
}

void insert_end(clist_t *ptr_clist, const char *name) {
  node_t *temp = create_node(name);

  if (ptr_clist->head == NULL) {
    temp->next = temp;
    ptr_clist->head = temp;
  } else {
    temp->next = ptr_clist->head->next;
    ptr_clist->head->next = temp;
    ptr_clist->head = temp;
  }
}

char *delete_beg(clist_t *ptr_clist) {
  static char name[25];
  if (ptr_clist->head == NULL) {
    printf("List is empty\n");
    return NULL;
  }

  node_t *first = ptr_clist->head->next;
  strcpy(name, first->name);

  if (ptr_clist->head == first) {
    ptr_clist->head = NULL;
  } else {
    ptr_clist->head->next = first->next;
  }

  free(first);
  return name;
}

void find_kth(clist_t *ptr_clist, int k) {
  if (ptr_clist->head == NULL || ptr_clist->head->next == ptr_clist->head) {
    return;
  }

  for (int i = 1; i < k; i++) {
    ptr_clist->head = ptr_clist->head->next;
  }
}

void disp_list(clist_t *ptr_clist) {
  if (ptr_clist->head == NULL) {
    printf("List is empty\n");
    return;
  }

  node_t *cur = ptr_clist->head->next;

  do {
    printf("%s ", cur->name);
    cur = cur->next;
  } while (cur != ptr_clist->head->next);

  printf("\n");
}

void free_clist(clist_t *ptr_clist) {
  if (ptr_clist->head == NULL) {
    return;
  }

  node_t *cur = ptr_clist->head->next;
  ptr_clist->head->next = NULL;

  while (cur != NULL) {
    node_t *next = cur->next;
    free(cur);
    cur = next;
  }

  ptr_clist->head = NULL;
}
