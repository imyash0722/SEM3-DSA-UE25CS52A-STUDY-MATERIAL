#include "clist.h"
#include <stdio.h>

int main() {
  clist_t j;
  init_clist(&j);
  int n, k;
  printf("Enter # of people and a magic number : ");
  scanf("%d %d", &n, &k);
  for (int i = 0; i < n; i++) {
    char name[25];
    scanf("%24s", name);
    insert_end(&j, name);
  }

  disp_list(&j);

  for (int i = 1; i < n; ++i) {
    find_kth(&j, k);
    printf("Removed : %s\n", delete_beg(&j));
  }
  printf("Survivor : ");
  disp_list(&j);
  free_clist(&j);

  return 0;
}
