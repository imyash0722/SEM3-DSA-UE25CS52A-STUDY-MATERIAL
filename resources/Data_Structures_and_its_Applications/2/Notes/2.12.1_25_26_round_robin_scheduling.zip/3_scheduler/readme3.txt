scheduling:
input:
circular doubly linked list of jobs
output:
schedule the jobs in round robin fashion

step 1:
job.h and job.c
add a field to the job.
job has 
job #
time to run : total time required for the job to complete
time so far : time allotted so far 

modify the set and display functions
add the function report_status_of_job which takes the time slice 
and adds it to time alloted so far. If the latter exceeds the 
time required by the job, the function indicates that the job is 
completed.

step 2 :
In the list type, add 
int process_job(dll_t *ptr_dll, int time_slice);
which will ask job to update the time allocated and signal 
if job completed.
if job completed, remove that node from the data structure.
Proceed to the next job.\\

step 3 :
change the client.
Support adding a job, processing a job, viewing the jobs in the 
circular list 



