#ifndef JOB_H
#define JOB_H 
struct job
{
	int job_no_;
	int time_to_run_;
	int time_so_far_;
};
typedef struct job job_t;
void set_job(job_t* ptr_job, int job_no, int time_to_run, int time_so_far);
void disp_job(job_t* ptr_job);
int report_status_of_job(job_t* ptr_job, int time_slice);
#endif