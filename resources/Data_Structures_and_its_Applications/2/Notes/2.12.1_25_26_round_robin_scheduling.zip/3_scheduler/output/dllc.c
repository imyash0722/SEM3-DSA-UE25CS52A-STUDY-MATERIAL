#include <stdio.h>
#include <stdlib.h>
#include "dllc.h"

void init_dll(dll_t *ptr_dll)
{
	ptr_dll->current_ = NULL;
}

void deinit_dll(dll_t *ptr_dll)
{
	node_t* pres = ptr_dll->current_;
    if(pres == NULL)
        return;
	do
	{
		node_t* temp = pres;
		pres = pres->next_;
		free(temp);
	} while(pres != ptr_dll->current);
	ptr_dll->current_ = NULL;
}

/* Create a new node */
static node_t* create_node(job_t job)
{
    node_t *temp;
    temp = (node_t*)malloc(sizeof(node_t));

	// one of the possible ways of handling an exceptional case
    if (temp == NULL) {
        printf("Memory allocation failed\n");
        exit(1);
    }
    temp->job_ = job;
    return temp;
}

/* add at the current position */
void add_current(dll_t *ptr_dll, job_t job)
{
    node_t *temp = create_node(job);
	if(ptr_dll->current_ == NULL)
	{
		temp->next_ = temp;
		temp->prev_ = temp;
		ptr_dll->current_ = temp;
	}
	else 
	{
		temp->next_ = ptr_dll->current_;
		temp->prev_ = ptr_dll->current_->prev_;
		temp->next_->prev_ = temp;
		temp->prev_->next_ = temp;
	}
}



/* Display from left to right */
void disp_forward(dll_t *ptr_dll)
{
    node_t *temp = ptr_dll->current_;
    printf("Forward: ");
	if(temp != NULL)
	{
		do
		{
			disp_job(&temp->job_);
			temp = temp->next_;
		} while (temp != ptr_dll->current_);
	}
    printf("\n");
}

/* Display from right to left */
void disp_backward(dll_t *ptr_dll)
{
    node_t *temp = ptr_dll->current_;
    printf("Backward: ");
	if(temp != NULL)
	{
		do
		{
			disp_job(&temp->job_);
			temp = temp->prev_;
		} while (temp != ptr_dll->current_);
	}
    printf("\n");
}

/* Delete current */
job_t delete_current(dll_t *ptr_dll)
{
    node_t *temp = ptr_dll->current_;

    if (temp == NULL) {
        printf("List is empty\n");
        exit(1);
    }
	job_t job = temp->job_;
	if(temp == temp->next_)
	{
		ptr_dll->current_ = NULL;
	}
	else 
	{
		ptr_dll->current_ = temp->next_;
		temp->next_->prev_ = temp->prev_;
		temp->prev_->next_ = temp->next_;
	}
	
	free(temp);
	return job;
}

int process_job(dll_t *ptr_dll, int time_slice)
{
	if(ptr_dll->current_ == NULL)
	{
		printf("empty\n"); exit(1);
	}
	int is_completed = report_status_of_job(&ptr_dll->current_->job_, time_slice);
	if(is_completed)
	{
		delete_current(ptr_dll);
	}
	else 
	{
		ptr_dll->current_ = ptr_dll->current_->next_;
	}
	return is_completed;
}


