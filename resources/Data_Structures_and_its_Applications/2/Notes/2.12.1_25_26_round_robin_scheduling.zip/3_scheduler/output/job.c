#include <stdio.h>
#include "job.h"

void set_job(job_t* ptr_job, int job_no, int time_to_run, int time_so_far)
{
	ptr_job->job_no_ = job_no;
	ptr_job->time_to_run_ = time_to_run;
	ptr_job->time_so_far_ = time_so_far;
}

void disp_job(job_t* ptr_job)
{
	printf("job # : %d\n", ptr_job->job_no_);
	printf("time to run : %d\n", ptr_job->time_to_run_);
	printf("time so far : %d\n", ptr_job->time_so_far_);
}
int report_status_of_job(job_t* ptr_job, int time_slice)
{
	int is_completed = 0;
	ptr_job->time_so_far_ += time_slice;
	if(ptr_job-> time_so_far_ >= ptr_job->time_to_run_)
	{
		ptr_job->time_so_far_ = ptr_job->time_to_run_;
		is_completed = 1;
	}
	return is_completed;
}
