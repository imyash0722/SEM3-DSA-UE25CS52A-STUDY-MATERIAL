#include <stdio.h>
#include "dllc.h" 



int main()
{
	dll_t q;
	init_dll(&q);
	int opt;
	int job_no = 1;
	int time_to_run;
	job_t job;
	int time_slice = 10; // 10 units of time
	int is_completed;
	printf("opt : 1 : enque; 2 : process ; 3 : disp forward "
		"4 : disp backward 0 : quit\n");
	scanf("%d", &opt);
	while(opt)
	{
		switch(opt)
		{
			case 1 :
						printf("enter time to run : ");
						scanf("%d", &time_to_run);
						set_job(&job, job_no++, time_to_run, 0);
						add_current(&q, job);
						break;
			case 2 : 	is_completed = process_job(&q, time_slice);
						if(is_completed)
						{
							printf("job removed\n");
						}
						break;
			case 3 : disp_forward(&q); break;
			case 4 : disp_backward(&q); break;

		}
		printf("opt : 1 : enque; 2 : process ; 3 : disp forward "
			"4 : disp backward 0 : quit\n");
		scanf("%d", &opt);
	}
	deinit_dll(&q);
}