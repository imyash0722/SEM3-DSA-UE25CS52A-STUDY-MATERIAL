Convert a doubly linked list to doubly linked circular list 
input : dll.c dll.h 
output : ddlc.c dllc.h 
Write a client program to test it.

