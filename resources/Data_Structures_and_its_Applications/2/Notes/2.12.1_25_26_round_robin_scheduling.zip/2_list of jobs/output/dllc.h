#ifndef DLL_H
#define DLL_H
#include "job.h"
struct node {
	
    job_t job_;
    struct node *prev_;
    struct node *next_;
};
typedef struct node node_t;

struct DLL {
	node_t *current_;
};
typedef struct DLL dll_t;
void init_dll(dll_t *ptr_dll);
void deinit_dll(dll_t *ptr_dll);
job_t delete_current(dll_t *ptr_dll);
void add_current(dll_t *ptr_dll, job_t job);


void disp_forward(dll_t *ptr_dll);
void disp_backward(dll_t *ptr_dll);
#if 0
// not required
void insert_begin(dll_t *ptr_dll, int key);
void insert_end(dll_t* ptr_dll, int key);
void insert_after(dll_t *ptr_dll, int key1, int key2);
void delete_begin(dll_t *ptr_dll);
void delete_end(dll_t *ptr_dll);
void delete_value(dll_t *ptr_dll, int key);
#endif

#endif