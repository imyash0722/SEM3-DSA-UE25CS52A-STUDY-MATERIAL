#ifndef JOB_H
#define JOB_H 
struct job
{
	int job_no_;
	int time_to_run_;
};
typedef struct job job_t;
void set_job(job_t* ptr_job, int job_no,  int time_to_run);
void disp_job(job_t* ptr_job);
#endif