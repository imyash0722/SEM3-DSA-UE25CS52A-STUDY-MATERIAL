#include <stdio.h>
#include "job.h"

void set_job(job_t* ptr_job, int job_no, int time_to_run)
{
	ptr_job->job_no_ = job_no;
	ptr_job->time_to_run_ = time_to_run;
}

void disp_job(job_t* ptr_job)
{
	printf("job # : %d\n", ptr_job->job_no_);
	printf("time to run : %d\n", ptr_job->time_to_run_);
}