Input: 
You are given the circular doubly linked list of int.
convert that to a circular doubly linked list of jobs.
each job shall have the following fields.

job #
time required to run 

We may add a few more fields later.

Hints:
create job.h job.c 
support set_job and disp_job 
change the dllc.h and dllc.c suitably
change the client suitably

Note: no scheduling; it is still a menu driven program 
 

