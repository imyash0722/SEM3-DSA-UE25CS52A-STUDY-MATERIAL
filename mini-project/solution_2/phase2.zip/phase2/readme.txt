continue with phase1
1. At each node, store a linked list
2. pick up the line number for each word
3. add them to this list.
4. When the trie is displayed,
		words are displayed in alphabetical order
		For each word display the line numbers
		line numbers are increasing order and not repeated.
		
input: input1.txt
Betty Botter bought some butter
but the butter was bitter
Betty Botter bought some better butter
to make the bitter butter better
	
output: (match this structure)
word : better : 3 4
word : betty : 1 3
word : bitter : 2 4
word : botter : 1 3
word : bought : 1 3
word : but : 2
word : butter : 1 2 3 4
word : make : 4
word : some : 1 3
word : the : 2 4
word : to : 4
word : was : 2