#ifndef PROCESS_TEXT_H
#define PROCESS_TEXT_H
void process_file(trie_t* tr, FILE *fp);

#endif

