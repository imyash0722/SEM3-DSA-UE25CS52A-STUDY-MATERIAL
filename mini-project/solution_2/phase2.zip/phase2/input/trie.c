#include <stdio.h>
#include <stdlib.h> 
#include <string.h>
#include "trie.h"
#include "stack.h"

static node_t* create_node()
{
	node_t* temp = (node_t*)malloc(sizeof(node_t));
	for(int i = 0; i < MAXSIZE; ++i)
	{
		temp->child_[i] = NULL;
	}
	temp->count_ = 0;
	return temp;
}

void init_trie(trie_t *ptr_trie)
{
	ptr_trie->root_ = create_node();
}

static void deinit_recursive(node_t *temp)
{
	for(int i = 0; i < MAXSIZE; ++i)
	{
		if(temp->child_[i])
		{
			deinit_recursive(temp->child_[i]);
		}
		free(temp->child_[i]);
	}
}
void deinit_trie(trie_t *ptr_trie)
{
	deinit_recursive(ptr_trie->root_);
}

// check if the word already exists and  increment the count in such a case
void insert_word(trie_t *ptr_trie, char* s)
{
	node_t* pres = ptr_trie->root_;
	int ch;
	while((ch = *s++) != '\0')
	{
		if(pres->child_[ch] == NULL)
		{
			pres->child_[ch] = create_node();
		}
		pres = pres->child_[ch];
	}
	++pres->count_;
}

static void display_recursive(node_t *pres, char word[], int* ptr_len)
{
	for(int i = 0; i < MAXSIZE; ++i)
	{
		if(pres->child_[i] != NULL)
		{
			word[(*ptr_len)++] = i;
			if(pres->child_[i]->count_)
			{
				word[*ptr_len] = '\0';
				printf("word : %s count : %d\n", word, pres->child_[i]->count_);
			}
			display_recursive(pres->child_[i], word, ptr_len);
			--(*ptr_len);  
		}
	}
	
}

void display(trie_t *ptr_trie)
{
	char word[MAXSIZE] = ""; 
	int len = 0;
	display_recursive(ptr_trie->root_, word, &len);
}

static node_t* prefix(node_t* pres, char* s)
{
	int ch;
	while((ch = *s++) != '\0')
	{
		if(pres->child_[ch] == NULL)
			return NULL;
		pres = pres->child_[ch];
	}
	return pres;
}

int search(trie_t *ptr_trie, char* s)
{
	node_t* pres = prefix(ptr_trie->root_, s);
	return (pres != NULL) && pres->count_;
}

void all_prefix(trie_t *ptr_trie, char* s)
{
	node_t* pres = prefix(ptr_trie->root_, s);
	if(pres == NULL)
		return;
	if(pres->count_)
		printf("word: %s count %d\n", s, pres->count_);
	char word[MAXSIZE];
	strcpy(word, s);
	int len = strlen(s);
	display_recursive(pres, word, &len);	
}

