#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "trie.h"


// string tokenizer
void word_to_lower(char s[])
{
	char *p = s;
	while(*p != '\0')
	{
		*p = tolower(*p);
		++p;
	}
}
void process_line(trie_t* tr, char line[], char delim[])
{
	char *token = strtok(line, delim); // string to tokenize - the first argument 
	// first time only
    while (token != NULL) {
		word_to_lower(token);
		insert_word(tr, token);
        //printf("%s\n", token);
        token = strtok(NULL, delim); // continue tokenizing the given string
    }
}

void process_file(trie_t* tr, FILE *fp)
{
	char line[MAXSIZE+1];
	char delim[20] = " \n";

	while(! feof(fp))
	{
		fgets(line, MAXSIZE, fp);
		process_line(tr, line, delim);
	}

}