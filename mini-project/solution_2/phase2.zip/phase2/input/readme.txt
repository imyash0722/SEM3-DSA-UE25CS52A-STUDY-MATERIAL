combine with the trie
modify trie to have the frequency
