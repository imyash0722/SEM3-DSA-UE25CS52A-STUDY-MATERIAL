#include <stdio.h>
#include <stdlib.h>

#include "trie.h" 
#include "process_text.h"


int main(int argc, char* argv[])
{
	trie_t t;
	init_trie(&t);

	char filename[20];
	strcpy(filename, argv[1]);
	FILE *fp;
	fp = fopen(filename, "r");
	if(fp == NULL)
	{
		perror(filename);
		exit(1);
	}
	
	process_file(&t, fp);
	fclose(fp);
	display(&t); 
	deinit_trie(&t);
}